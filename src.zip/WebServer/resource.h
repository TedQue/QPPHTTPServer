//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WebServer.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_WebServerTYPE               129
#define IDD_DIALOG_SETTING              130
#define IDD_DIALOG1                     131
#define IDC_EDIT1                       1000
#define IDC_CHECK1                      1001
#define IDC_CHECK2                      1002
#define IDC_EDIT2                       1003
#define IDC_CHECK3                      1004
#define IDC_EDIT3                       1005
#define IDC_EDIT4                       1006
#define IDC_EDIT5                       1007
#define IDC_EDIT6                       1008
#define IDC_EDIT7                       1009
#define IDC_CHECK4                      1010
#define IDC_CHECK5                      1011
#define IDC_EDIT8                       1012
#define IDC_CHECK6                      1013
#define IDC_EDIT9                       1014
#define IDC_EDIT10                      1015
#define IDC_EDIT11                      1016
#define IDC_EDIT12                      1017
#define IDC_EDIT13                      1018
#define IDC_EDIT14                      1019
#define IDC_COMBO1                      1020
#define IDC_EDIT15                      1021
#define IDC_EDIT16                      1022
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_SETTING                      32774
#define ID_START                        32775
#define ID_STOP                         32776
#define ID_PAUSE                        32777
#define ID_LOG                          32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_MAKE_LIST                    32781
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_ENABLE_LOG                   32785
#define ID_CLEAR_LOG                    32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
